const express = require('express');
const router = express.Router();

const AsaasController = require('../controllers/AsaasController');

router.get('/get', AsaasController.getPaymentStatuses);

module.exports = router;
