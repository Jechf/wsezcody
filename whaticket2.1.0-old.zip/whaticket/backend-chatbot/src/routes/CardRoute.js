const express = require('express');
const router = express.Router();

const CardController = require('../controllers/CardController');

router.get('/list', CardController.list);
router.post('/create', CardController.create);
router.get('/get/:id', CardController.get);
router.post('/update/:id', CardController.update);
router.post('/delete', CardController.delete);

module.exports = router;